﻿namespace NFZ.Models
{
    public static class ProductList
    {
       
    }
}
