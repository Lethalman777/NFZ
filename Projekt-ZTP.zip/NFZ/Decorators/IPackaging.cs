﻿namespace NFZ.Decorators
{
    public interface IPackaging
    {
        public decimal Cena();
        public String Opis();
    }
}
